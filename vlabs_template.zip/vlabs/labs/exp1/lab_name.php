<?php 
$lab_name = "Lab Name";

$exp_name = "Experiment Name";

$_SESSION['lab_name'] = $lab_name;
$_SESSION['exp_name'] = $exp_name;
?>